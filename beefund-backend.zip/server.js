require('dotenv').config();
const express = require('express');
const mongoose = require('mongoose');
const cors = require('cors');
const jwt = require('jsonwebtoken');
const bcrypt = require('bcryptjs');

const app = express();
app.use(cors());
app.use(express.json());

mongoose.connect(process.env.MONGODB_URI, { useNewUrlParser: true, useUnifiedTopology: true });

const userSchema = new mongoose.Schema({
  nome: String,
  email: { type: String, unique: true },
  senha: String
});

const User = mongoose.model('User', userSchema);

app.post('/api/register', async (req, res) => {
  const { nome, email, senha } = req.body;
  try {
    const hash = await bcrypt.hash(senha, 10);
    const user = await User.create({ nome, email, senha: hash });
    res.json({ message: 'Usuário registrado com sucesso!' });
  } catch (err) {
    res.status(400).json({ error: 'Erro ao registrar. Email pode estar em uso.' });
  }
});

app.post('/api/login', async (req, res) => {
  const { email, senha } = req.body;
  const user = await User.findOne({ email });
  if (!user) return res.status(404).json({ error: 'Usuário não encontrado' });

  const isMatch = await bcrypt.compare(senha, user.senha);
  if (!isMatch) return res.status(401).json({ error: 'Senha incorreta' });

  const token = jwt.sign({ id: user._id }, process.env.JWT_SECRET);
  res.json({ token });
});

app.get('/api/painel', async (req, res) => {
  const token = req.headers.authorization;
  if (!token) return res.status(403).json({ error: 'Token ausente' });

  try {
    const decoded = jwt.verify(token, process.env.JWT_SECRET);
    const user = await User.findById(decoded.id);
    res.json({
      nome: user.nome,
      saldo: "10000.00",
      rendimento: "32.5%"
    });
  } catch (err) {
    res.status(401).json({ error: 'Token inválido' });
  }
});

const PORT = process.env.PORT || 3000;
app.listen(PORT, () => console.log(`Servidor rodando na porta ${PORT}`));